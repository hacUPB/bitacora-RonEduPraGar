#pragma once
#include "ofMain.h"

class Particle;

class Behavior {
public:
	virtual ~Behavior() = default;
	virtual void apply(Particle & p, float deltaTime) = 0;
};

#include "ofApp.h"
#include "Behaviors.h"

void ofApp::setup() {
	ofSetFrameRate(60);
	ofBackground(10);
	emitter = std::make_unique<Emitter>(ofVec2f(ofGetWidth() * 0.5f, ofGetHeight() * 0.5f));
	lastEmit = 0;
}

void ofApp::update() {
	float deltaTime = ofGetLastFrameTime();
	if (ofGetElapsedTimef() - lastEmit > 0.05f) {
		emitter->emit(2);
		lastEmit = ofGetElapsedTimef();
	}
	emitter->update(deltaTime);

	for (auto & p : emitter->getParticles()) {
		if (!attractors.empty()) {
			p->addBehavior(std::make_shared<AttractorBehavior>(attractors.front()->getPosition(), 400.0f));
		}
	}
}

void ofApp::draw() {
	ofEnableBlendMode(OF_BLENDMODE_ADD);
	emitter->draw();
	ofEnableBlendMode(OF_BLENDMODE_ALPHA);

	ofSetColor(255, 150);
	for (auto & a : attractors) {
		ofDrawCircle(a->getPosition(), 6);
	}

	ofSetColor(255);
	ofDrawBitmapStringHighlight("Click to create attractor. Press 'c' clear.", 10, 20);
}

void ofApp::mousePressed(int x, int y, int button) {
	auto a = std::make_shared<Particle>(ofVec2f(x, y), 1.0f);
	a->setColor(ofColor::yellow);
	attractors.push_back(a);
}

void ofApp::mouseDragged(int x, int y, int button) {
	if (!attractors.empty()) {
		attractors.front() = std::make_shared<Particle>(ofVec2f(x, y), 1.0f);
	}
}

void ofApp::keyPressed(int key) {
	if (key == 'c') {
		attractors.clear();
		emitter->clear();
	}
}

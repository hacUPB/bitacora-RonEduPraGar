#pragma once
#include "Emitter.h"
#include "ofMain.h"

class ofApp : public ofBaseApp {
public:
	void setup() override;
	void update() override;
	void draw() override;
	void mouseDragged(int x, int y, int button) override;
	void mousePressed(int x, int y, int button) override;
	void keyPressed(int key) override;

private:
	std::unique_ptr<Emitter> emitter;
	std::vector<std::shared_ptr<Particle>> attractors;
	float lastEmit;
};

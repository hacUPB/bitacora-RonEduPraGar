#include "Behaviors.h"

// --- SeekBehavior ---
SeekBehavior::SeekBehavior(const ofVec2f & t, float s)
	: target(t)
	, strength(s) { }

void SeekBehavior::setTarget(const ofVec2f & t) { target = t; }

void SeekBehavior::apply(Particle & p, float deltaTime) {
	ofVec2f desired = (target - p.getPosition());
	float d = desired.length();
	if (d > 0.0001f) {
		desired.normalize();
		float speed = ofMap(d, 0, 200, 0, 300, true);
		desired *= speed;
		ofVec2f steer = (desired - p.getVelocity());
		p.applyForce(steer * (strength / 100.0f));
	}
}

// --- FleeBehavior ---
FleeBehavior::FleeBehavior(const ofVec2f & t, float r, float s)
	: threat(t)
	, panicRadius(r)
	, strength(s) { }

void FleeBehavior::setThreat(const ofVec2f & t) { threat = t; }

void FleeBehavior::apply(Particle & p, float deltaTime) {
	ofVec2f diff = p.getPosition() - threat;
	float d = diff.length();
	if (d < panicRadius && d > 0.0001f) {
		diff.normalize();
		diff *= (strength * (1.0f - d / panicRadius));
		p.applyForce(diff);
	}
}

// --- WanderBehavior ---
WanderBehavior::WanderBehavior(float radius, float jitter)
	: wanderRadius(radius)
	, wanderJitter(jitter) {
	wanderTarget.set(ofRandom(-1, 1), ofRandom(-1, 1));
	wanderTarget.normalize();
}

void WanderBehavior::apply(Particle & p, float deltaTime) {
	ofVec2f jitter(ofRandom(-1, 1) * wanderJitter * deltaTime, ofRandom(-1, 1) * wanderJitter * deltaTime);
	wanderTarget += jitter;
	wanderTarget.normalize();
	ofVec2f target = p.getVelocity();
	target.normalize();
	target *= wanderRadius;
	target += wanderTarget;
	ofVec2f steer = target - p.getVelocity();
	p.applyForce(steer * 0.5f);
}

// --- NoiseBehavior ---
NoiseBehavior::NoiseBehavior(float s, float str)
	: scale(s)
	, strength(str) { }

void NoiseBehavior::apply(Particle & p, float deltaTime) {
	float t = ofGetElapsedTimef();
	ofVec2f pos = p.getPosition();
	float angle = ofNoise(pos.x * scale, pos.y * scale, t * 0.1f) * TWO_PI * 2.0f;
	ofVec2f force(cos(angle), sin(angle));
	p.applyForce(force * strength * deltaTime);
}

// --- AttractorBehavior ---
AttractorBehavior::AttractorBehavior(const ofVec2f & pt, float s)
	: point(pt)
	, strength(s) { }

void AttractorBehavior::setTargetPoint(const ofVec2f & pnt) { point = pnt; }

void AttractorBehavior::apply(Particle & p, float deltaTime) {
	ofVec2f dir = point - p.getPosition();
	float d = dir.length();
	if (d > 1.0f) {
		dir.normalize();
		float f = strength / (d * d);
		p.applyForce(dir * f * deltaTime);
	}
}

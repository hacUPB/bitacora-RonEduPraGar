#pragma once
#include "Behavior.h"
#include "Particle.h"

// Declaraciones de las clases de comportamiento
class SeekBehavior : public Behavior {
public:
	SeekBehavior(const ofVec2f & target, float strength = 100.0f);
	void setTarget(const ofVec2f & t);
	void apply(Particle & p, float deltaTime) override;

private:
	ofVec2f target;
	float strength;
};

class FleeBehavior : public Behavior {
public:
	FleeBehavior(const ofVec2f & threat, float panicRadius = 80.0f, float strength = 150.0f);
	void setThreat(const ofVec2f & t);
	void apply(Particle & p, float deltaTime) override;

private:
	ofVec2f threat;
	float panicRadius;
	float strength;
};

class WanderBehavior : public Behavior {
public:
	WanderBehavior(float radius = 20.0f, float jitter = 40.0f);
	void apply(Particle & p, float deltaTime) override;

private:
	ofVec2f wanderTarget;
	float wanderRadius;
	float wanderJitter;
};

class NoiseBehavior : public Behavior {
public:
	NoiseBehavior(float scale = 0.002f, float strength = 50.0f);
	void apply(Particle & p, float deltaTime) override;

private:
	float scale;
	float strength;
};

class AttractorBehavior : public Behavior {
public:
	AttractorBehavior(const ofVec2f & point, float strength = 200.0f);
	void setTargetPoint(const ofVec2f & pnt);
	void apply(Particle & p, float deltaTime) override;

private:
	ofVec2f point;
	float strength;
};

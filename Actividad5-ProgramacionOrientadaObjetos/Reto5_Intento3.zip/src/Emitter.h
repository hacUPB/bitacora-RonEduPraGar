#pragma once
#include "Particle.h"
#include "ofMain.h"
#include <memory>
#include <vector>

class Emitter {
public:
	Emitter(const ofVec2f & pos);
	void update(float deltaTime);
	void draw() const;
	void emit(int n);
	void setPosition(const ofVec2f & p) { position = p; }
	void clear();

	std::vector<std::shared_ptr<Particle>> & getParticles() { return particles; }

private:
	ofVec2f position;
	std::vector<std::shared_ptr<Particle>> particles;
};

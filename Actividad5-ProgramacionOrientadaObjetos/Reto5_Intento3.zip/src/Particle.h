#pragma once
#include "ofMain.h"
#include <memory>
#include <vector>

class Behavior;

class Particle {
public:
	Particle(const ofVec2f & pos, float mass = 1.0f);
	virtual ~Particle() = default;

	ofVec2f getPosition() const;
	ofVec2f getVelocity() const;
	float getMass() const;
	float getRadius() const;

	void setColor(const ofColor & c);
	ofColor getColor() const;

	void applyForce(const ofVec2f & force);

	void addBehavior(const std::shared_ptr<Behavior> & behavior);
	void clearBehaviors();

	virtual void update(float deltaTime);
	virtual void draw() const;

	bool isDead() const;
	void kill();

protected:
	ofVec2f position;
	ofVec2f velocity;
	ofVec2f acceleration;
	float mass;
	float radius;
	ofColor color;
	bool dead;

	std::vector<std::shared_ptr<Behavior>> behaviors;
};

#include "Particle.h"
#include "Behavior.h"

Particle::Particle(const ofVec2f & pos, float m)
	: position(pos)
	, velocity(0, 0)
	, acceleration(0, 0)
	, mass(m)
	, radius(ofClamp(m * 3.0f, 2.0f, 12.0f))
	, color(ofColor::white)
	, dead(false) { }

ofVec2f Particle::getPosition() const { return position; }
ofVec2f Particle::getVelocity() const { return velocity; }
float Particle::getMass() const { return mass; }
float Particle::getRadius() const { return radius; }

void Particle::setColor(const ofColor & c) { color = c; }
ofColor Particle::getColor() const { return color; }

void Particle::applyForce(const ofVec2f & force) {
	acceleration += force / mass;
}

void Particle::addBehavior(const std::shared_ptr<Behavior> & behavior) {
	behaviors.push_back(behavior);
}

void Particle::clearBehaviors() {
	behaviors.clear();
}

void Particle::update(float deltaTime) {
	for (auto & b : behaviors) {
		if (b) b->apply(*this, deltaTime);
	}
	velocity += acceleration * deltaTime;
	position += velocity * deltaTime;
	velocity *= 0.995f;
	acceleration.set(0, 0);
}

void Particle::draw() const {
	ofPushStyle();
	ofSetColor(color);
	ofDrawCircle(position, radius);
	ofPopStyle();
}

bool Particle::isDead() const { return dead; }
void Particle::kill() { dead = true; }

#include "Emitter.h"
#include "Behaviors.cpp" // quick include for behaviors and particle types
#include <memory>

Emitter::Emitter(const ofVec2f & pos)
	: position(pos) { }

void Emitter::emit(int n) {
	for (int i = 0; i < n; i++) {
		auto p = std::make_shared<Particle>(position, ofRandom(0.5f, 3.0f));
		// give random initial velocity
		p->applyForce(ofVec2f(ofRandom(-30, 30), ofRandom(-30, 30)));
		// add some behaviors (example mix)
		p->addBehavior(std::make_shared<WanderBehavior>(20.0f, 40.0f));
		p->addBehavior(std::make_shared<NoiseBehavior>(0.004f, 40.0f));
		p->setColor(ofColor::fromHsb(ofRandom(0, 255), 200, 255));
		particles.push_back(p);
	}
}

void Emitter::update(float dt) {
	for (auto & p : particles) {
		p->update(dt);
		// optionally: kill if offscreen
		if (p->getPosition().x < -50 || p->getPosition().x > ofGetWidth() + 50 || p->getPosition().y < -50 || p->getPosition().y > ofGetHeight() + 50) {
			p->kill();
		}
	}
	// remove dead
	particles.erase(std::remove_if(particles.begin(), particles.end(),
						[](const std::shared_ptr<Particle> & p) { return p->isDead(); }),
		particles.end());
}

void Emitter::draw() const {
	for (auto & p : particles)
		p->draw();
}

void Emitter::clear() { particles.clear(); }

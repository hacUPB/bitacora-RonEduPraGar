#include "ofApp.h"
#include "Particle.cpp"
#include "Emitter.cpp"
#include "Behaviors.cpp" // quick include for behavior classes

void ofApp::setup() {
	ofSetFrameRate(60);
	ofBackground(10);
	emitter = std::make_unique<Emitter>(ofVec2f(ofGetWidth() * 0.5f, ofGetHeight() * 0.5f));
	lastEmit = 0;
}

void ofApp::update() {
	float dt = ofGetLastFrameTime();
	// auto spawn
	if (ofGetElapsedTimef() - lastEmit > 0.05f) {
		emitter->emit(2);
		lastEmit = ofGetElapsedTimef();
	}
	emitter->update(dt);

	// Add an attractor behavior to all particles towards mouse if any attractors exist
	for (auto & p : emitter->getParticles()) {
		// dynamic polymorphism: create a transient Attractor behavior per-particle (or shared)
		if (!attractors.empty()) {
			// for simplicity, remove previous AttractorBehavior and add new
			p->addBehavior(std::make_shared<AttractorBehavior>(attractors.front()->getPosition(), 400.0f));
		}
	}
}

void ofApp::draw() {
	ofEnableBlendMode(OF_BLENDMODE_ADD);
	emitter->draw();
	ofEnableBlendMode(OF_BLENDMODE_ALPHA);

	// draw attractor markers
	ofSetColor(255, 150);
	for (auto & a : attractors) {
		ofDrawCircle(a->getPosition(), 6);
	}

	ofSetColor(255);
	ofDrawBitmapStringHighlight("Click to create attractor. Press 'c' clear.", 10, 20);
}

void ofApp::mousePressed(int x, int y, int button) {
	// create a simple attractor represented as a Particle (not participating)
	auto a = std::make_shared<Particle>(ofVec2f(x, y), 1.0f);
	a->setColor(ofColor::yellow);
	attractors.push_back(a);
}

void ofApp::mouseDragged(int x, int y, int button) {
	// move first attractor
	if (!attractors.empty()) {
		// hacky setter via access to position via reflection? But we kept position protected.
		// For simplicity, kill and recreate:
		attractors.front() = std::make_shared<Particle>(ofVec2f(x, y), 1.0f);
	}
}

void ofApp::keyPressed(int key) {
	if (key == 'c') {
		attractors.clear();
		emitter->clear();
	}
}

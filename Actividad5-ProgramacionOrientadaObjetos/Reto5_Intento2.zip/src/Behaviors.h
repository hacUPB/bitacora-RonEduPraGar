#pragma once
#include "ofMain.h"

class Particle;

class Behaviors {
public:
	virtual ~Behaviors() = default;
	// Polimorfismo: cada comportamiento implementa apply
	virtual void apply(Particle & p, float dt) = 0;
};

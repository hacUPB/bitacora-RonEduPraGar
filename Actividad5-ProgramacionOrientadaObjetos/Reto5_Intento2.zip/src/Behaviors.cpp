#include "Behaviors.h"
#include "Particle.h"

// --- SeekBehavior ---
class SeekBehavior : public Behaviors {
public:
	SeekBehavior(const ofVec2f & target, float strength = 100.0f)
		: target(target)
		, strength(strength) { }
	void setTarget(const ofVec2f & t) { target = t; }

	void apply(Particle & p, float dt) override {
		ofVec2f desired = (target - p.getPosition());
		float d = desired.length();
		if (d > 0.0001f) {
			desired.normalize();
			float speed = ofMap(d, 0, 200, 0, 300, true);
			desired *= speed;
			ofVec2f steer = (desired - p.getVelocity());
			p.applyForce(steer * (strength / 100.0f));
		}
	}

private:
	ofVec2f target;
	float strength;
};

// --- FleeBehavior ---
class FleeBehavior : public Behaviors {
public:
	FleeBehavior(const ofVec2f & threat, float panicRadius = 80.0f, float strength = 150.0f)
		: threat(threat)
		, panicRadius(panicRadius)
		, strength(strength) { }
	void setThreat(const ofVec2f & t) { threat = t; }
	void apply(Particle & p, float dt) override {
		ofVec2f diff = p.getPosition() - threat;
		float d = diff.length();
		if (d < panicRadius && d > 0.0001f) {
			diff.normalize();
			diff *= (strength * (1.0f - d / panicRadius));
			p.applyForce(diff);
		}
	}

private:
	ofVec2f threat;
	float panicRadius;
	float strength;
};

// --- WanderBehavior ---
class WanderBehavior : public Behaviors {
public:
	WanderBehavior(float radius = 20.0f, float jitter = 40.0f)
		: wanderRadius(radius)
		, wanderJitter(jitter) {
		wanderTarget.set(ofRandom(-1, 1), ofRandom(-1, 1));
		wanderTarget.normalize();
	}
	void apply(Particle & p, float dt) override {
		// small random displacement
		ofVec2f jitter(ofRandom(-1, 1) * wanderJitter * dt, ofRandom(-1, 1) * wanderJitter * dt);
		wanderTarget += jitter;
		wanderTarget.normalize();
		ofVec2f target = p.getVelocity();
		target.normalize();
		target *= wanderRadius;
		target += wanderTarget;
		ofVec2f steer = target - p.getVelocity();
		p.applyForce(steer * 0.5f);
	}

private:
	ofVec2f wanderTarget;
	float wanderRadius;
	float wanderJitter;
};

// --- NoiseBehavior ---
class NoiseBehavior : public Behaviors {
public:
	NoiseBehavior(float scale = 0.002f, float strength = 50.0f)
		: scale(scale)
		, strength(strength) { }
	void apply(Particle & p, float dt) override {
		float t = ofGetElapsedTimef();
		ofVec2f pos = p.getPosition();
		float angle = ofNoise(pos.x * scale, pos.y * scale, t * 0.1f) * TWO_PI * 2.0f;
		ofVec2f force(cos(angle), sin(angle));
		p.applyForce(force * strength * dt);
	}

private:
	float scale;
	float strength;
};

// --- AttractorBehavior (gravitational-like) ---
class AttractorBehavior : public Behaviors {
public:
	AttractorBehavior(const ofVec2f & point, float strength = 200.0f)
		: point(point)
		, strength(strength) { }
	void setPoint(const ofVec2f & pnt) { point = pnt; }
	void apply(Particle & p, float dt) override {
		ofVec2f dir = point - p.getPosition();
		float d = dir.length();
		if (d > 1.0f) {
			dir.normalize();
			// inverse-square-ish falloff
			float f = strength / (d * d);
			p.applyForce(dir * f * dt);
		}
	}

private:
	ofVec2f point;
	float strength;
};

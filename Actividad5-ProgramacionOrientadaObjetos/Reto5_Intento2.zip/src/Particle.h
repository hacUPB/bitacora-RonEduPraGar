#pragma once
#include "ofMain.h"
#include <memory>
#include <vector>

class Behaviors; // forward

class Particle {
public:
	Particle(const ofVec2f & pos, float mass = 1.0f);
	virtual ~Particle() = default;

	// Encapsulamiento: acceso controlado
	ofVec2f getPosition() const;
	ofVec2f getVelocity() const;
	float getMass() const;
	float getRadius() const;
	void setColor(const ofColor & c);
	ofColor getColor() const;

	// Forces & behaviors
	void applyForce(const ofVec2f & force);
	void addBehavior(std::shared_ptr<Behaviors> behavior);
	void clearBehaviors();

	// Main lifecycle
	virtual void update(float dt);
	virtual void draw() const;

	// convenience
	bool isDead() const;
	void kill();

protected:
	// Internals (encapsulados)
	ofVec2f position;
	ofVec2f velocity;
	ofVec2f acceleration;
	float mass;
	float radius;
	ofColor color;
	bool dead;

	std::vector<std::shared_ptr<Behaviors>> behaviors;
};
